/**
 * 
 */
/**
 * 
 */
module scholar {
	requires java.desktop;
	requires java.sql;
}